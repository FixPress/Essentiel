                        <!-- Lazy Loading -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Lazy Loading', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Activer le Lazy Loading des images', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[advanced_cache_lazy_loading_enabled]" value="1" <?php checked(1, $options['advanced_cache_lazy_loading_enabled'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Charge les images uniquement lorsqu\'elles sont visibles.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Activer le Lazy Loading des vidéos et iframes', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[advanced_cache_lazy_loading_videos_enabled]" value="1" <?php checked(1, $options['advanced_cache_lazy_loading_videos_enabled'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Charge les vidéos et iframes uniquement lorsqu\'elles sont visibles.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Préchargement -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Préchargement', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Activer le préchargement des liens', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[advanced_cache_preload_links]" value="1" <?php checked(1, $options['advanced_cache_preload_links'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Précharge les liens pour une navigation plus rapide.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Gestion des caches mobiles -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Caches mobiles', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Activer un cache distinct pour les mobiles', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[advanced_cache_mobile_cache_enabled]" value="1" <?php checked(1, $options['advanced_cache_mobile_cache_enabled'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Ajoute un cache spécifique pour les appareils mobiles afin d\'optimiser les performances.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Intégration CDN -->
                        <tr>
                            <th colspan="2"><h3><?php _e('CDN', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Activer l\'intégration CDN', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[advanced_cache_cdn_enabled]" value="1" <?php checked(1, $options['advanced_cache_cdn_enabled'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Utilise un CDN pour distribuer les ressources plus rapidement.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Nettoyage automatique -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Nettoyage automatique', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Planifier le nettoyage des caches', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[advanced_cache_cleanup_enabled]" value="1" <?php checked(1, $options['advanced_cache_cleanup_enabled'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Planifie un nettoyage quotidien des fichiers de cache obsolètes.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(__('Enregistrer les paramètres', 'essentiel')); ?>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php } ?>