<?php
// Empêche l'accès direct
if (!defined('ABSPATH')) {
    exit;
}

class EssentielRGPD {
    public static function init() {
        // Ajout de la bannière RGPD
        add_action('wp_footer', [__CLASS__, 'add_cookie_banner']);
        // Chargement des styles CSS pour la bannière
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_rgpd_styles']);
    }

    public static function add_cookie_banner() {
        echo '<div id="cookie-banner">
                <p>Ce site utilise des cookies pour améliorer votre expérience. <button id="accept-cookies">Accepter</button> <button id="reject-cookies">Refuser</button></p>
              </div>';
    }

    public static function enqueue_rgpd_styles() {
        wp_enqueue_style(
            'essentiel-rgpd-css',
            plugin_dir_url(__FILE__) . '../assets/css/rgpd.css',
            [],
            '1.0'
        );
    }
}

EssentielRGPD::init();
