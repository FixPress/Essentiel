<?php
// Empêche l'accès direct
if (!defined('ABSPATH')) {
    exit;
}

class EssentielDBCleanup {
    public static function init() {
        // Planification pour le nettoyage de la base de données
        if (!wp_next_scheduled('essentiel_db_cleanup_event')) {
            wp_schedule_event(time(), 'daily', 'essentiel_db_cleanup_event');
        }
        add_action('essentiel_db_cleanup_event', [__CLASS__, 'cleanup_database']);
    }

    public static function cleanup_database() {
        global $wpdb;
        // Exemple : Suppression des révisions
        $wpdb->query("DELETE FROM $wpdb->posts WHERE post_type = 'revision'");
    }
}

EssentielDBCleanup::init();
