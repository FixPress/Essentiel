<?php
if (!defined('ABSPATH')) exit;

/**
 * Ajoute le menu admin
 */
function essentiel_add_admin_menu() {
    add_menu_page(
        __('Essentiel', 'essentiel'),
        __('Essentiel', 'essentiel'),
        'manage_options',
        'essentiel-settings',
        'essentiel_render_admin_page',
        'dashicons-shield-alt',
        80
    );
}
add_action('admin_menu', 'essentiel_add_admin_menu');

/**
 * Enregistre les réglages
 */
function essentiel_register_settings() {
    register_setting('essentiel_options_group', 'essentiel_options', 'essentiel_sanitize_options');
}
add_action('admin_init', 'essentiel_register_settings');


/**
 * Fonction de sanitisation pour les options
 */
function essentiel_sanitize_options($input) {
    // Récupère les options existantes
    $existing_options = get_option('essentiel_options', []);

    // Fusionne les options soumises avec les existantes
    $output = array_merge($existing_options, $input);

    // Ajoutez ici des vérifications ou modifications si nécessaire
    return $output;
}

/**
 * Affiche la page admin
 */
function essentiel_render_admin_page() {
    $options = get_option('essentiel_options');
    $active_tab = isset($_GET['tab']) && in_array($_GET['tab'], ['presentation', 'security', 'cache', 'seo', 'rgpd', 'db']) ? $_GET['tab'] : 'presentation';

    $tabs = [
        'presentation' => __('Présentation', 'essentiel'),
        'security'     => __('Sécurité', 'essentiel'),
        'cache'        => __('Cache / Performance', 'essentiel'),
        'seo'          => __('SEO', 'essentiel'),
        'rgpd'         => __('RGPD', 'essentiel'),
        'db'           => __('Base de données', 'essentiel'),
    ];
    ?>
    <div class="wrap">
        <div class="essentiel-header">
            <img src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/svg/fixpress.svg'); ?>" alt="Essentiel logo" class="essentiel-logo" />
        </div>

        <h2 class="nav-tab-wrapper">
            <?php foreach ($tabs as $key => $label) : ?>
                <a href="<?php echo esc_url('?page=essentiel-settings&tab=' . $key); ?>" class="nav-tab <?php echo esc_attr(($active_tab === $key) ? 'nav-tab-active' : ''); ?>">
                    <?php echo esc_html($label); ?>
                </a>
            <?php endforeach; ?>
        </h2>

        <div class="essentiel-tab-content" style="margin-top: 20px;">
            <?php if ($active_tab === 'presentation') : ?>
                <div class="essentiel-presentation">
                    <h2>Essentiel : Minimaliste par défaut — puissant sur demande</h2>
                    
                    <p>Essentiel simplifie l’administration de votre site WordPress en offrant des fonctionnalités puissantes, sans complexité inutile. Il vous permet d'améliorer la sécurité, la performance, le SEO, et bien plus, tout en restant léger et facile à utiliser.</p>
                    
                    <h3>Fonctionnalités principales :</h3>
                    <ul>
                        <li><strong>Sécurité</strong> : protection contre les vulnérabilités courantes et les attaques par force brute.</li>
                        <li><strong>Performance</strong> : mise en cache, compression, minification, et optimisation des ressources pour un site plus rapide.</li>
                        <li><strong>SEO</strong> : optimisation pour un meilleur classement dans les moteurs de recherche, y compris les balises meta et URL propres.</li>
                        <li><strong>RGPD</strong> : conformité avec la législation européenne sur la protection des données personnelles.</li>
                    </ul>
                    <h3>Mode d’emploi simplifié :</h3>
                    <ol>
                        <li><strong>1. Naviguez</strong> : Utilisez les onglets en haut pour explorer les différentes fonctionnalités.</li>
                        <li><strong>2. Activez</strong> : Cochez les options que vous souhaitez activer dans chaque section.</li>
                        <li><strong>3. Enregistrez</strong> : Cliquez sur le bouton “Enregistrer les paramètres” pour sauvegarder vos modifications.</li>
                        <li><strong>4. Personnalisez</strong> : Activez les fonctionnalités qui correspondent à vos besoins pour améliorer votre site.</li>
                    </ol>

                    <h3>Précautions d’usage :</h3>
                    <ul>
                        <li>Avant de modifier des paramètres sensibles (comme la sécurité), assurez-vous de bien comprendre les implications de chaque option.</li>
                        <li>Testez les modifications dans un environnement de pré-production avant de les appliquer en production pour éviter tout risque de conflit avec d’autres plugins ou thèmes.</li>
                        <li>En cas de doute, désactivez une fonctionnalité et vérifiez son impact avant d'activer définitivement.</li>
                    </ul>
                    
                    
                </div>
            <?php endif; ?>

            <?php if ($active_tab === 'security') : ?>
                <div class="essentiel-security">
                    <h2><?php _e('Sécurité', 'essentiel'); ?></h2>
                    <p><?php _e('Configurez les options de sécurité pour protéger votre site.', 'essentiel'); ?></p>
                    <!-- Ajouter des champs de configuration de sécurité ici -->
                                   <form method="post" action="options.php">
                    <?php settings_fields('essentiel_options_group'); ?>
                    <table class="form-table">
                        <!-- Protection des fichiers sensibles -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Protection des fichiers sensibles', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Désactiver l&rsquo;éditeur de fichiers', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_disable_file_editor]" value="1" <?php checked(1, $options['security_disable_file_editor'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Empêche les utilisateurs d&rsquo;accéder et de modifier directement les fichiers via l&rsquo;éditeur de thèmes ou de plugins.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Protéger les fichiers critiques', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_protect_critical_files]" value="1" <?php checked(1, $options['security_protect_critical_files'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Ajoute une protection pour empêcher l&rsquo;accès aux fichiers sensibles comme wp-config.php et .htaccess.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Empêcher l&rsquo;exécution de fichiers PHP dans les uploads', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_protect_uploads_folder]" value="1" <?php checked(1, $options['security_protect_uploads_folder'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Ajoute une règle pour bloquer l&rsquo;exécution de fichiers PHP dans le dossier des téléchargements.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Sécurisation des authentifications -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Sécurisation des authentifications', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Limiter les tentatives de connexion', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_limit_login_attempts]" value="1" <?php checked(1, $options['security_limit_login_attempts'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Bloque temporairement les utilisateurs après plusieurs tentatives de connexion échouées.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Ajouter un honeypot', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_add_honeypot]" value="1" <?php checked(1, $options['security_add_honeypot'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Ajoute un champ invisible pour piéger les robots et bloquer les soumissions suspectes.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Ajouter un CAPTCHA sur la page de connexion', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_captcha_on_login]" value="1" <?php checked(1, $options['security_captcha_on_login'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Ajoute un test CAPTCHA pour renforcer la sécurité sur la page de connexion.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Personnaliser l&rsquo;URL de connexion', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_custom_login_url]" value="1" <?php checked(1, $options['security_custom_login_url'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Modifie l&rsquo;URL de connexion pour une sécurité accrue.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Sécurisation des communications -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Sécurisation des communications', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Forcer HTTPS', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_force_https]" value="1" <?php checked(1, $options['security_force_https'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Redirige automatiquement les utilisateurs vers la version sécurisée (HTTPS) du site.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Désactiver XML-RPC', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_disable_xml_rpc]" value="1" <?php checked(1, $options['security_disable_xml_rpc'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Désactive l&rsquo;accès XML-RPC pour réduire les risques d&rsquo;attaques.', 'essentiel'); ?></p>
                            </td>
                        </tr>

                        <!-- Protection contre les abus -->
                        <tr>
                            <th colspan="2"><h3><?php _e('Protection contre les abus', 'essentiel'); ?></h3></th>
                        </tr>
                        <tr>
                            <th><?php _e('Bloquer les agents utilisateurs malveillants', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_block_bad_user_agents]" value="1" <?php checked(1, $options['security_block_bad_user_agents'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Empêche l&rsquo;accès des bots identifiés comme malveillants.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Bloquer les connexions par Geo-IP', 'essentiel'); ?></th>
                            <td>
                                <label class="essentiel-switch">
                                    <input type="checkbox" name="essentiel_options[security_block_geo_ip]" value="1" <?php checked(1, $options['security_block_geo_ip'] ?? 0); ?> />
                                    <span class="essentiel-slider"></span>
                                </label>
                                <p class="description"><?php _e('Restreint l&rsquo;accès au site en fonction des zones géographiques.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(__('Enregistrer les paramètres', 'essentiel')); ?>
                </form>
                </div>
            <?php endif; ?>

            <?php if ($active_tab === 'cache') : ?>
                <div class="essentiel-cache">
                    <h2><?php _e('Cache / Performance', 'essentiel'); ?></h2>
                    <p><?php _e('Optimisez les performances du site en configurant le cache et d’autres options de performance.', 'essentiel'); ?></p>
                    <!-- Ajouter des champs de configuration de cache ici -->
                                    <form method="post" action="options.php">
                    <?php settings_fields('essentiel_options_group'); ?>
                    <table class="form-table">
                        <tr>
                <th colspan="2">
                    <h3><?php _e('Cache des pages', 'essentiel'); ?></h3>
                </th>
            </tr>
            <tr>
                <th><?php _e('Activer le cache des pages', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[enable_page_cache]" value="1" <?php checked(1, $options['enable_page_cache'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Met en cache les pages pour les visiteurs non connectés afin de réduire les temps de chargement.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Section Compression -->
            <tr>
                <th colspan="2">
                    <h3><?php _e('Compression', 'essentiel'); ?></h3>
                </th>
            </tr>
            <tr>
                <th><?php _e('Activer la compression Gzip', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[enable_gzip]" value="1" <?php checked(1, $options['enable_gzip'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Active la compression Gzip pour réduire la taille des fichiers envoyés au navigateur.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Section Optimisation des ressources -->
            <tr>
                <th colspan="2">
                    <h3><?php _e('Optimisation des ressources', 'essentiel'); ?></h3>
                </th>
            </tr>
            <tr>
                <th><?php _e('Activer la minification des fichiers CSS et JS', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[enable_minification]" value="1" <?php checked(1, $options['enable_minification'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Réduit la taille des fichiers CSS et JS en supprimant les espaces inutiles et les commentaires.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer le préchargement des liens', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[preload_links]" value="1" <?php checked(1, $options['preload_links'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Précharge les ressources des liens avant que l’utilisateur ne clique dessus.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer le préchargement des polices Google', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[preload_google_fonts]" value="1" <?php checked(1, $options['preload_google_fonts'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Précharge les polices Google pour améliorer la vitesse de chargement des pages.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Section Nettoyage -->
            <tr>
                <th colspan="2">
                    <h3><?php _e('Nettoyage automatique', 'essentiel'); ?></h3>
                </th>
            </tr>
            <tr>
                <th><?php _e('Activer le nettoyage planifié des caches', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[scheduled_cache_cleanup]" value="1" <?php checked(1, $options['scheduled_cache_cleanup'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                                <p class="description"><?php esc_html_e('Met en cache les pages pour les visiteurs non connectés.', 'essentiel'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(esc_html__('Enregistrer les paramètres', 'essentiel')); ?>
                                </form>
                    
                </div>
            <?php endif; ?>

            <?php if ($active_tab === 'seo') : ?>
                <div class="essentiel-seo">
                    <h2><?php _e('SEO', 'essentiel'); ?></h2>
                    <p><?php _e('Configurez les options SEO pour améliorer le classement de votre site sur les moteurs de recherche.', 'essentiel'); ?></p>
                    <!-- Ajouter des champs de configuration SEO ici -->
<!-- SEO -->
    <form method="post" action="options.php">
        <?php settings_fields('essentiel_options_group'); ?>
        <table class="form-table">

            <!-- Métadonnées et balises SEO -->
            <tr>
                <th colspan="2"><h3><?php _e('Métadonnées et balises SEO', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Activer les balises Meta', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_meta_tags_enabled]" value="1" <?php checked(1, $options['seo_meta_tags_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Ajoute des balises meta description sur toutes les pages.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer les balises Open Graph et Twitter Cards', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_open_graph_enabled]" value="1" <?php checked(1, $options['seo_open_graph_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Ajoute des balises Open Graph et Twitter Cards pour les réseaux sociaux.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer les balises Canonical', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_canonical_enabled]" value="1" <?php checked(1, $options['seo_canonical_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Ajoute une balise canonical pour éviter les contenus dupliqués.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer les balises Robots', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_robots_enabled]" value="1" <?php checked(1, $options['seo_robots_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Ajoute des directives pour les moteurs de recherche (noindex, nofollow).', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer le titre SEO personnalisé', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_title_enabled]" value="1" <?php checked(1, $options['seo_title_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Génère dynamiquement un titre optimisé pour le SEO.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Optimisation des performances -->
            <tr>
                <th colspan="2"><h3><?php _e('Optimisation des performances', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Désactiver les scripts inutiles', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_disable_unused_scripts]" value="1" <?php checked(1, $options['seo_disable_unused_scripts'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Améliore les performances en désactivant les scripts inutiles.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer l’optimisation des images', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_image_optimization_enabled]" value="1" <?php checked(1, $options['seo_image_optimization_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Ajoute automatiquement les attributs alt et title aux images.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Sitemap et données structurées -->
            <tr>
                <th colspan="2"><h3><?php _e('Sitemap et données structurées', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Activer le Sitemap XML', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_sitemap_enabled]" value="1" <?php checked(1, $options['seo_sitemap_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Génère dynamiquement un fichier Sitemap XML.', 'essentiel'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php _e('Activer les balises Schema.org', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_schema_enabled]" value="1" <?php checked(1, $options['seo_schema_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Ajoute des balises structurées JSON-LD pour les moteurs de recherche.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Gestion des redirections -->
            <tr>
                <th colspan="2"><h3><?php _e('Gestion des redirections', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Activer les redirections 301', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_redirects_enabled]" value="1" <?php checked(1, $options['seo_redirects_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Gère automatiquement les redirections lors des changements d’URL.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Analyse de contenu -->
            <tr>
                <th colspan="2"><h3><?php _e('Analyse de contenu', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Activer l’analyse des mots-clés', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[seo_keyword_analysis_enabled]" value="1" <?php checked(1, $options['seo_keyword_analysis_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Analyse la fréquence des mots-clés dans le contenu.', 'essentiel'); ?></p>
                </td>
            </tr>
        </table>
        <?php submit_button(__('Enregistrer les paramètres', 'essentiel')); ?>
    </form>                
    
                </div>
            <?php endif; ?>

            <?php if ($active_tab === 'rgpd') : ?>
                <div class="essentiel-rgpd">
                    <h2><?php _e('RGPD', 'essentiel'); ?></h2>
                    <p><?php _e('Configurez les options RGPD pour la conformité avec la législation sur la protection des données.', 'essentiel'); ?></p>
                    <!-- Ajouter des champs de configuration RGPD ici -->
                    <form method="post" action="options.php">
        <?php settings_fields('essentiel_options_group'); ?>
        <table class="form-table">

            <!-- Bannière de consentement -->
            <tr>
                <th colspan="2"><h3><?php _e('Bannière de consentement', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Afficher la bannière RGPD', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[rgpd_cookie_banner_enabled]" value="1" <?php checked(1, $options['rgpd_cookie_banner_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Affiche une bannière RGPD pour demander le consentement des utilisateurs concernant les cookies.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Gestion des styles -->
            <tr>
                <th colspan="2"><h3><?php _e('Styles et personnalisation', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Activer les styles pour la bannière', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[rgpd_styles_enabled]" value="1" <?php checked(1, $options['rgpd_styles_enabled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Charge les styles CSS nécessaires pour la bannière RGPD.', 'essentiel'); ?></p>
                </td>
            </tr>
        </table>
        <?php submit_button(__('Enregistrer les paramètres', 'essentiel')); ?>
    </form>
                    
                </div>
            <?php endif; ?>

            <?php if ($active_tab === 'db') : ?>
                <div class="essentiel-db">
                    <h2><?php _e('Base de données', 'essentiel'); ?></h2>
                    <p><?php _e('Optimisez la gestion de votre base de données ici.', 'essentiel'); ?></p>
                    <!-- Ajouter des champs de configuration de base de données ici -->
                    <!-- Nettoyage de la base de données -->
    <form method="post" action="options.php">
        <?php settings_fields('essentiel_options_group'); ?>
        <table class="form-table">

            <!-- Planification du nettoyage -->
            <tr>
                <th colspan="2"><h3><?php _e('Planification du nettoyage', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Activer le nettoyage automatique', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[db_cleanup_scheduled]" value="1" <?php checked(1, $options['db_cleanup_scheduled'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Planifie un nettoyage automatique quotidien de la base de données.', 'essentiel'); ?></p>
                </td>
            </tr>

            <!-- Suppression des données inutiles -->
            <tr>
                <th colspan="2"><h3><?php _e('Suppression des données inutiles', 'essentiel'); ?></h3></th>
            </tr>
            <tr>
                <th><?php _e('Supprimer les révisions', 'essentiel'); ?></th>
                <td>
                    <label class="essentiel-switch">
                        <input type="checkbox" name="essentiel_options[db_cleanup_revisions]" value="1" <?php checked(1, $options['db_cleanup_revisions'] ?? 0); ?> />
                        <span class="essentiel-slider"></span>
                    </label>
                    <p class="description"><?php _e('Supprime automatiquement les révisions d’articles pour réduire le poids de la base de données.', 'essentiel'); ?></p>
                </td>
            </tr>
        </table>
        <?php submit_button(__('Enregistrer les paramètres', 'essentiel')); ?>
    </form>
                    
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
