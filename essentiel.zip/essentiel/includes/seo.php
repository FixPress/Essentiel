<?php
// Empêche l'accès direct
if (!defined('ABSPATH')) {
    exit;
}

class EssentielSEO {
    public static function init() {
        // Ajout des balises méta
        add_action('wp_head', [__CLASS__, 'add_meta_tags']);
        // Ajout des balises Open Graph et Twitter Cards
        add_action('wp_head', [__CLASS__, 'add_open_graph_tags']);
        // Ajout d'une balise canonical
        add_action('wp_head', [__CLASS__, 'add_canonical_tag']);
        // Gestion des balises robots
        add_action('wp_head', [__CLASS__, 'add_robots_meta']);
        // Ajout d'un titre SEO personnalisé
        add_action('wp_head', [__CLASS__, 'add_seo_title']);
        // Désactiver les scripts inutilisés pour optimiser les performances
        add_action('init', [__CLASS__, 'disable_unused_scripts']);
        // Génération d'un sitemap XML
        add_action('init', [__CLASS__, 'generate_sitemap']);
        // Ajout de balises Schema.org (JSON-LD)
        add_action('wp_head', [__CLASS__, 'add_schema_markup']);
        // Optimisation automatique des images
        add_filter('the_content', [__CLASS__, 'optimize_images']);
        // Gestion des redirections 301
        add_action('template_redirect', [__CLASS__, 'handle_redirections']);
        // Analyse simple des mots-clés SEO dans le contenu
        add_action('save_post', [__CLASS__, 'keyword_analysis']);
    }

    public static function add_meta_tags() {
        echo '<meta name="description" content="Optimisé pour le SEO avec Essentiel">';
    }

    public static function add_open_graph_tags() {
        echo '<meta property="og:title" content="' . esc_attr(get_the_title()) . '">';
        echo '<meta property="og:description" content="' . esc_attr(get_bloginfo('description')) . '">';
        echo '<meta property="og:image" content="' . esc_url(get_template_directory_uri() . '/assets/images/default-og-image.jpg') . '">';
        echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '">';
        echo '<meta name="twitter:card" content="summary_large_image">';
    }

    public static function add_canonical_tag() {
        echo '<link rel="canonical" href="' . esc_url(get_permalink()) . '">';
    }

    public static function add_robots_meta() {
        if (is_search() || is_404()) {
            echo '<meta name="robots" content="noindex, nofollow">';
        }
    }

    public static function add_seo_title() {
        echo '<title>' . esc_html(wp_title('|', false, 'right') . get_bloginfo('name')) . '</title>';
    }

    public static function disable_unused_scripts() {
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('wp_print_styles', 'print_emoji_styles');
    }

    public static function generate_sitemap() {
        if (isset($_GET['generate_sitemap'])) {
            header("Content-Type: application/xml; charset=utf-8");
            echo '<?xml version="1.0" encoding="UTF-8"?>';
            echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
            
            $posts = get_posts(['numberposts' => -1, 'post_status' => 'publish']);
            foreach ($posts as $post) {
                echo '<url>';
                echo '<loc>' . esc_url(get_permalink($post->ID)) . '</loc>';
                echo '<lastmod>' . esc_html(get_the_modified_date('c', $post->ID)) . '</lastmod>';
                echo '</url>';
            }

            echo '</urlset>';
            exit;
        }
    }

    public static function add_schema_markup() {
        if (is_single()) {
            $schema = [
                "@context" => "https://schema.org",
                "@type" => "Article",
                "headline" => get_the_title(),
                "datePublished" => get_the_date('c'),
                "dateModified" => get_the_modified_date('c'),
                "author" => [
                    "@type" => "Person",
                    "name" => get_the_author(),
                ],
                "publisher" => [
                    "@type" => "Organization",
                    "name" => get_bloginfo('name'),
                ],
            ];
            echo '<script type="application/ld+json">' . json_encode($schema) . '</script>';
        }
    }

    public static function optimize_images($content) {
        $content = preg_replace_callback('/<img([^>]+)>/', function($matches) {
            if (strpos($matches[1], 'alt=') === false) {
                $matches[1] .= ' alt="Image description"';
            }
            if (strpos($matches[1], 'title=') === false) {
                $matches[1] .= ' title="Image title"';
            }
            return '<img' . $matches[1] . '>';
        }, $content);
        return $content;
    }

    public static function handle_redirections($post_id) {
        $old_url = get_post_meta($post_id, '_old_url', true);
        $new_url = get_permalink($post_id);

        if ($old_url && $old_url !== $new_url) {
            header("Location: $new_url", true, 301);
            exit;
        }

        update_post_meta($post_id, '_old_url', $new_url);
    }

    public static function keyword_analysis($post_id) {
        $post = get_post($post_id);
        $content = $post->post_content;
        $keyword = "SEO";
        $count = substr_count(strtolower($content), strtolower($keyword));
        update_post_meta($post_id, '_seo_keyword_count', $count);
    }
}

// Initialisation des fonctionnalités SEO
EssentielSEO::init();