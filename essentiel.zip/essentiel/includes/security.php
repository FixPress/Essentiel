<?php
if (!defined('ABSPATH')) exit;

class EssentielCache {
    public static function init() {
        // Initialiser les options si elles ne sont pas définies
        self::init_options();

        // Activer le cache des pages
        if (get_option('essentiel_cache_page_cache_enabled')) {
            add_action('template_redirect', [__CLASS__, 'enable_page_cache']);
        }

        // Activer la minification des CSS et JS
        if (get_option('essentiel_cache_minify_enabled')) {
            add_filter('script_loader_tag', [__CLASS__, 'defer_js'], 10, 2);
            add_filter('style_loader_tag', [__CLASS__, 'defer_css'], 10, 2);
        }

        // Compression Gzip
        if (get_option('essentiel_cache_gzip_enabled')) {
            add_action('init', [__CLASS__, 'enable_gzip_compression']);
        }

        // Préchargement des liens
        if (get_option('essentiel_cache_preload_links')) {
            add_action('wp_head', [__CLASS__, 'preload_links'], 10);
        }

        // Préchargement des polices Google
        if (get_option('essentiel_cache_preload_google_fonts')) {
            add_action('wp_head', [__CLASS__, 'preload_google_fonts'], 10);
        }

        // Optimisation des images (WebP/AVIF)
        if (get_option('essentiel_cache_images_webp_avif')) {
            add_filter('the_content', [__CLASS__, 'optimize_images']);
        }

        // Planification du nettoyage des caches
        self::schedule_cleanup();
    }

    /**
     * Initialiser les options par défaut.
     */
    public static function init_options() {
        $defaults = [
            'essentiel_cache_page_cache_enabled' => false,
            'essentiel_cache_minify_enabled' => false,
            'essentiel_cache_gzip_enabled' => false,
            'essentiel_cache_preload_links' => false,
            'essentiel_cache_preload_google_fonts' => false,
            'essentiel_cache_images_webp_avif' => false,
        ];

        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                update_option($key, $value);
            }
        }
    }

    /**
     * Activer le cache des pages.
     */
    public static function enable_page_cache() {
        if (is_user_logged_in() || is_admin()) {
            return; // Ne pas mettre en cache pour les utilisateurs connectés ou l'administration
        }

        $cache_file = WP_CONTENT_DIR . '/cache/' . md5($_SERVER['REQUEST_URI']) . '.html';
        if (file_exists($cache_file) && time() - filemtime($cache_file) < 3600) {
            // Servir le fichier cache s'il existe et n'est pas expiré
            echo file_get_contents($cache_file);
            exit;
        }

        // Capturer la sortie en tampon
        ob_start();
        add_action('shutdown', function () use ($cache_file) {
            $output = ob_get_clean();
            file_put_contents($cache_file, $output);
            echo $output;
        });
    }

    /**
     * Différer le chargement des fichiers JS.
     */
    public static function defer_js($tag, $handle) {
        return str_replace('<script ', '<script defer ', $tag);
    }

    /**
     * Différer le chargement des fichiers CSS.
     */
    public static function defer_css($tag, $handle) {
        if (strpos($tag, 'media="all"') !== false) {
            return str_replace('media="all"', 'media="print" onload="this.media=\'all\'"', $tag);
        }
        return $tag;
    }

    /**
     * Activer la compression Gzip.
     */
    public static function enable_gzip_compression() {
        if (!ini_get('zlib.output_compression')) {
            ob_start('ob_gzhandler');
        }
    }

    /**
     * Précharger les liens critiques.
     */
    public static function preload_links() {
        // Précharger les styles CSS enregistrés
        $styles = wp_styles();
        if (!empty($styles->queue)) {
            foreach ($styles->queue as $handle) {
                $src = $styles->registered[$handle]->src ?? '';
                if ($src) {
                    echo '<link rel="preload" href="' . esc_url($src) . '" as="style">' . PHP_EOL;
                }
            }
        }

        // Précharger les scripts JS enregistrés
        $scripts = wp_scripts();
        if (!empty($scripts->queue)) {
            foreach ($scripts->queue as $handle) {
                $src = $scripts->registered[$handle]->src ?? '';
                if ($src) {
                    echo '<link rel="preload" href="' . esc_url($src) . '" as="script">' . PHP_EOL;
                }
            }
        }
    }

    /**
     * Précharger les polices Google.
     */
    public static function preload_google_fonts() {
        echo '<link rel="preload" href="https://fonts.googleapis.com/css?family=Roboto" as="font" type="font/woff2" crossorigin="anonymous">' . PHP_EOL;
    }

    /**
     * Optimiser les images (remplacement par WebP ou AVIF si disponibles).
     */
    public static function optimize_images($content) {
        return preg_replace_callback('/\.(jpg|jpeg|png)/', function ($matches) {
            $file_path = str_replace(home_url(), ABSPATH, $matches[0]);
            $webp = str_replace($matches[0], '.webp', $file_path);
            $avif = str_replace($matches[0], '.avif', $file_path);
            if (file_exists($webp)) {
                return str_replace($file_path, $webp, $matches[0]);
            } elseif (file_exists($avif)) {
                return str_replace($file_path, $avif, $matches[0]);
            }
            return $matches[0];
        }, $content);
    }

    /**
     * Planifier une tâche CRON pour nettoyer les caches expirés.
     */
    public static function schedule_cleanup() {
        if (!wp_next_scheduled('essentiel_cache_cleanup')) {
            wp_schedule_event(time(), 'daily', 'essentiel_cache_cleanup');
        }
        add_action('essentiel_cache_cleanup', [__CLASS__, 'cleanup']);
    }

    /**
     * Nettoyer les fichiers de cache expirés.
     */
    public static function cleanup() {
        $cache_files = glob(WP_CONTENT_DIR . '/cache/*.html');
        foreach ($cache_files as $file) {
            if (time() - filemtime($file) > 3600) {
                unlink($file);
            }
        }
    }
}

// Initialisation de la classe
EssentielCache::init();