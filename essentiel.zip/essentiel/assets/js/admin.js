// ----------- Interactivité améliorée -----------

// Basculer entre mode clair et sombre
document.addEventListener('DOMContentLoaded', function () {
    const toggleButton = document.createElement('div');
    toggleButton.className = 'theme-toggle';
    toggleButton.innerText = 'Mode Sombre';
    document.body.appendChild(toggleButton);

    toggleButton.addEventListener('click', function () {
        document.body.classList.toggle('dark-mode');
        const isDarkMode = document.body.classList.contains('dark-mode');
        toggleButton.innerText = isDarkMode ? 'Mode Clair' : 'Mode Sombre';
    });
});

// Ajouter des transitions douces entre onglets
document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('nav-tab-active'));
        tab.classList.add('nav-tab-active');

        const targetTab = tab.getAttribute('href').split('&tab=')[1];
        document.querySelectorAll('.essentiel-tab-content > div').forEach(content => {
            content.style.display = content.classList.contains(`essentiel-${targetTab}`) ? 'block' : 'none';
        });
    });
});

// Infobulles pour aider les utilisateurs
document.querySelectorAll('.tooltip').forEach(tooltip => {
    tooltip.addEventListener('mouseover', function () {
        const tooltipText = this.querySelector('.tooltip-text');
        if (tooltipText) tooltipText.style.visibility = 'visible';
    });
    tooltip.addEventListener('mouseout', function () {
        const tooltipText = this.querySelector('.tooltip-text');
        if (tooltipText) tooltipText.style.visibility = 'hidden';
    });
});

// Confirmation visuelle après sauvegarde
document.querySelector('.submit input[type="submit"]').addEventListener('click', function () {
    const confirmation = document.createElement('div');
    confirmation.innerText = 'Paramètres enregistrés avec succès !';
    confirmation.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #0073aa;
        color: white;
        padding: 15px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    `;
    document.body.appendChild(confirmation);
    setTimeout(() => confirmation.remove(), 3000);
});