<?php
/*
Plugin Name: Essentiel
Description: Un plugin léger et modulaire pour sécurité, performance, SEO, RGPD et maintenance.
Version: 1.0
Author: FixPress
Text Domain: essentiel
Domain Path: /languages
*/

if (!defined('ABSPATH')) exit;

// Chargement des modules — toujours actifs
require_once plugin_dir_path(__FILE__) . "includes/admin-ui.php";

// Chargement du CSS pour la page admin du plugin
function essentiel_enqueue_assets($hook) {
    if (strpos($hook, 'essentiel') === false) return;

    wp_enqueue_style(
        'essentiel-admin-style',
        plugin_dir_url(__FILE__) . 'assets/css/admin.css',
        [],
        time()
    );
}
add_action('admin_enqueue_scripts', 'essentiel_enqueue_assets');

// Chargement des traductions
function essentiel_load_textdomain() {
    load_plugin_textdomain('essentiel', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'essentiel_load_textdomain');

function essentiel_test_ui_page() {
    add_menu_page('Test Essentiel', 'Essai Essentiel', 'manage_options', 'test-essentiel', 'essentiel_test_render');
}
add_action('admin_menu', 'essentiel_test_ui_page');

function essentiel_test_render() {
    echo '<div class="wrap">';
    echo '<h1>Test Onglets</h1>';
    echo '<h2 class="nav-tab-wrapper">';
    echo '<a class="nav-tab nav-tab-active" href="#">Onglet 1</a>';
    echo '<a class="nav-tab" href="#">Onglet 2</a>';
    echo '</h2>';
    echo '<div><p>Contenu test</p></div>';
    echo '</div>';
}
